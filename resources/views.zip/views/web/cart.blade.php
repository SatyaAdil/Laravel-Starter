<x-layout>
    <x-slot:title>{{ $title }}</x-slot>

        <h3>Ini adalah halaman Keranjang Belanja</h3>
</x-layout>