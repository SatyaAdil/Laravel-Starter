<x-layout>
    <x-slot:title>{{ $title }}</x-slot>
        <h3>Ini adalah halaman All Categories</h3>
</x-layout>
