<x-layout>
    <h3>Ini adalah halaman Single Product</h3>
</x-layout>