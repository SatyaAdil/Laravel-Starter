<x-layout>
    <x-slot:title>{{ $title }}</x-slot>

        <h3>Ini adalah halaman Category - {{ $slug }}</h3>
</x-layout>